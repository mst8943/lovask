declare module 'adm-zip';
