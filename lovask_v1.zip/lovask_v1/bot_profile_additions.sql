alter table public.profiles add column if not exists is_bot boolean default false;
